# BasicStatisticsSpark

Small project in Scala IDE. Example used in the subject Big Data II.

How to read a dataset, calculate the summary statistics and write the output.

How to compile and run with maven.
