#!/bin/bash
mvn clean
